--[[
    GD50
    Match-3 Remake

    -- Board Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    The Board is our arrangement of Tiles with which we must try to find matching
    sets of three horizontally or vertically.
]]

Board = Class{}

function Board:init(x, y, level)
    self.x = x
    self.y = y
    self.matches = {}

    self:initializeTiles(level)
	
end

function Board:initializeTiles(level)
    self.tiles = {}
	self.level = level
	
	-- used to see if the board is playable
	self.anyMatches = 1
	
	-- contains variety for easy reference when calculating tiles in each level
	self.variety = 1
	
	-- colors I've chosen for the game
	local tileTable = {1,2,5,6,9,11,12,14,17}

    for tileY = 1, 8 do
        
        -- empty table that will serve as a new row
        table.insert(self.tiles, {})

        for tileX = 1, 8 do
			
			-- chance to get a shiny tile is 1/25 for each tile
			shinyTile = math.random(1,25)
			
			if self.level == 1 then
				
		        -- create a new tile at X,Y with a random color and variety
				-- changed random tiles to include 8 to reduce the number of tiles in the game
				table.insert(self.tiles[tileY], Tile(tileX, tileY, tileTable[math.random(1,#tileTable)], self.variety, shinyTile))
		
			elseif self.level < 6 then
				self.variety = math.random(1, self.level)
				table.insert(self.tiles[tileY], Tile(tileX, tileY, tileTable[math.random(1,#tileTable)], self.variety, shinyTile))
			
			else
				self.variety = math.random(6)	
				table.insert(self.tiles[tileY], Tile(tileX, tileY, tileTable[math.random(1,#tileTable)], self.variety, shinyTile))
			end
            

        end
    end

    while self:calculateMatches() do
        
        -- recursively initialize if matches were returned so we always have
        -- a matchless board on start
        self:initializeTiles(self.level)
    end
	

	while anyMatches == 1 do
	
		-- check if swapping every tile gives a match or not and keep track
		self:potentialMatches(anyMatches)
	
		-- if there were no matches in that loop, re-initialize the board
		if anyMatches == 1 then
			self:initializeTiles(self.level)
		end	
	
	end

end

--[[
	Loop to go through all intersections, no need to go past 7 as 7 will swap with 8 in the loop.
	also don't need to tween, just need to change their positions and check for matches, then
	swap back if not resetting the board
]]

function Board:potentialMatches(anyMatches)
		self.anyMatches = anyMatches
		for boardx =  1,8 do
			for boardy = 1,7 do			

				-- variables to help with the circle
				local temp = self.tiles[boardy][boardx]
				local tempX = boardx			
				local tempY = boardy			
				
				self.tiles[boardy][boardx] = self.tiles[boardy+1][boardx]
				self.tiles[boardy+1][boardx] = temp
				
				-- after the swap, test for matches. If there are some, we're good to exit this loop
				if self:calculateMatches() then
				
					self.anyMatches = self.anyMatches + 1
				end	
				
				-- extra variable for the swap back
				local tempTween = self.tiles[boardy][boardx]
				
				self.tiles[boardy][boardx] = self.tiles[boardy+1][boardx]
				self.tiles[boardy+1][boardx] = tempTween

			end
		end	
		
		-- check the same for x instead of y
		for boardy = 1,8 do
			for boardx = 1,7 do			
				
				-- variables to help with the swap
				local temp = self.tiles[boardy][boardx]
				local tempX = boardx			
				local tempY = boardy			
				
				self.tiles[boardy][boardx] = self.tiles[boardy][boardx+1]
				self.tiles[boardy][boardx+1] = temp
				
				-- after the swap, test for matches. If there are some, we're good to exit this loop
				if self:calculateMatches() then
				
					self.anyMatches = self.anyMatches + 1
				end	
				
				-- extra variable for the swap back
				local tempTween = self.tiles[boardy][boardx]
				
				self.tiles[boardy][boardx] = self.tiles[boardy][boardx+1]
				self.tiles[boardy][boardx+1] = tempTween

			end
		end

	return self.anyMatches
end


--[[
    Goes left to right, top to bottom in the board, calculating matches by counting consecutive
    tiles of the same color. Doesn't need to check the last tile in every row or column if the 
    last two haven't been a match.
	
	If something is shiny and matches, it adds the entire row to the match table for removal
]]
function Board:calculateMatches()
    local matches = {}

	-- used to calculate extra score based on variety
	local varietyScore = 0
    -- how many of the same color blocks in a row we've found
    local matchNum = 1

    -- horizontal matches first
    for y = 1, 8 do
        local colorToMatch = self.tiles[y][1].color

        matchNum = 1
        
        -- every horizontal tile
        for x = 2, 8 do
            
            -- if this is the same color as the one we're trying to match...
            if self.tiles[y][x].color == colorToMatch then
                matchNum = matchNum + 1
            else
                
                -- set this as the new color we want to watch for
                colorToMatch = self.tiles[y][x].color

                -- if we have a match of 3 or more up to now, add it to our matches table
                if matchNum >= 3 then
                    local match = {}

                    -- go backwards from here by matchNum
                    for x2 = x - 1, x - matchNum, -1 do
                        
						if self.tiles[y][x2].shiny == 1 then
							for x2 =1,8 do
								table.insert(match, self.tiles[y][x2])
							end	
						else
							-- add each tile to the match that's in that match
							table.insert(match, self.tiles[y][x2])
						end	
						
						-- summing for extra score based on variety
						varietyScore = varietyScore + (self.tiles[y][x2].variety - 1)
                    end

                    -- add this match to our total matches table
                    table.insert(matches, match)
                end

                matchNum = 1

                -- don't need to check last two if they won't be in a match
                if x >= 7 then
                    break
                end
            end
        end

        -- account for the last row ending with a match
        if matchNum >= 3 then
            local match = {}
            
            -- go backwards from end of last row by matchNum
            for x = 8, 8 - matchNum + 1, -1 do
			
				if self.tiles[y][x].shiny == 1 then
					for x =1,8 do
						table.insert(match, self.tiles[y][x])
					end	
				else
					-- add each tile to the match that's in that match
					table.insert(match, self.tiles[y][x])
				end					
				
				-- summing for extra score based on variety
				varietyScore = varietyScore + (self.tiles[y][x].variety - 1)				
            end

            table.insert(matches, match)
        end
    end

    -- vertical matches
    for x = 1, 8 do
        local colorToMatch = self.tiles[1][x].color

        matchNum = 1

        -- every vertical tile
        for y = 2, 8 do
            if self.tiles[y][x].color == colorToMatch then
                matchNum = matchNum + 1
            else
                colorToMatch = self.tiles[y][x].color

                if matchNum >= 3 then
                    local match = {}

                    for y2 = y - 1, y - matchNum, -1 do
					
						if self.tiles[y2][x].shiny == 1 then
							for x =1,8 do
								table.insert(match, self.tiles[y2][x])
							end
						else
							-- add each tile to the match that's in that match
							table.insert(match, self.tiles[y2][x])
						end	
						
						-- summing for extra score based on variety
						varietyScore = varietyScore + (self.tiles[y2][x].variety - 1)						
                    end

                    table.insert(matches, match)
                end

                matchNum = 1

                -- don't need to check last two if they won't be in a match
                if y >= 7 then
                    break
                end
            end
        end

        -- account for the last column ending with a match
        if matchNum >= 3 then
            local match = {}
            
            -- go backwards from end of last row by matchNum
            for y = 8, 8 - matchNum + 1, -1 do
			
				if self.tiles[y][x].shiny == 1 then
					for x =1,8 do
						table.insert(match, self.tiles[y][x])
					end	
				else
					-- add each tile to the match that's in that match
					table.insert(match, self.tiles[y][x])
				end				

				varietyScore = varietyScore + (self.tiles[y][x].variety - 1)							
            end

            table.insert(matches, match)
        end
    end

    -- store matches for later reference
    self.matches = matches

    -- return matches table if > 0, else just return false	
	if #self.matches > 0 then
		return self.matches, varietyScore
	else
		return false
	end


	
end

--[[
    Remove the matches from the Board by just setting the Tile slots within
    them to nil, then setting self.matches to nil.
]]
function Board:removeMatches()
    for k, match in pairs(self.matches) do
        for k, tile in pairs(match) do
            self.tiles[tile.gridY][tile.gridX] = nil
        end
    end

    self.matches = nil
end

--[[
    Shifts down all of the tiles that now have spaces below them, then returns a table that
    contains tweening information for these new tiles.
]]
function Board:getFallingTiles(level)
    -- tween table, with tiles as keys and their x and y as the to values
    local tweens = {}
	
	-- tile table for replacement tiles
	local tileTable = {1,2,5,6,9,11,12,14,17}

    -- for each column, go up tile by tile till we hit a space
    for x = 1, 8 do
        local space = false
        local spaceY = 0

        local y = 8
        while y >= 1 do
            
            -- if our last tile was a space...
            local tile = self.tiles[y][x]
            
            if space then
                
                -- if the current tile is *not* a space, bring this down to the lowest space
                if tile then
                    
                    -- put the tile in the correct spot in the board and fix its grid positions
                    self.tiles[spaceY][x] = tile
                    tile.gridY = spaceY

                    -- set its prior position to nil
                    self.tiles[y][x] = nil

                    -- tween the Y position to 32 x its grid position
                    tweens[tile] = {
                        y = (tile.gridY - 1) * 32
                    }

                    -- set Y to spaceY so we start back from here again
                    space = false
                    y = spaceY

                    -- set this back to 0 so we know we don't have an active space
                    spaceY = 0
                end
            elseif tile == nil then
                space = true
                
                -- if we haven't assigned a space yet, set this to it
                if spaceY == 0 then
                    spaceY = y
                end
            end

            y = y - 1
        end
    end

    -- create replacement tiles at the top of the screen
    for x = 1, 8 do
        for y = 8, 1, -1 do
			
			-- replacements can also be shiny
			shinyTile = math.random(1,25)
			
            local tile = self.tiles[y][x]
			local variety = 1

            -- if the tile is nil, we need to add a new one
            if not tile then

                -- new tile with random color and variety
				-- updated to match original 8
				-- only load some designs based on level
				if level == 1 then
				
					local tile = Tile(x, y, tileTable[math.random(1,#tileTable)], variety, shinyTile)
					tile.y = -32
					self.tiles[y][x] = tile

					-- create a new tween to return for this tile to fall down
					tweens[tile] = {
						y = (tile.gridY - 1) * 32
					}
				elseif level < 6 then
				
					variety = math.random(1, level)
					
					local tile = Tile(x, y, tileTable[math.random(1,#tileTable)], variety, shinyTile)
					
					tile.y = -32
					self.tiles[y][x] = tile

					-- create a new tween to return for this tile to fall down
					tweens[tile] = {
						y = (tile.gridY - 1) * 32
					}
				else
					variety = math.random(6)
					local tile = Tile(x, y, tileTable[math.random(1,#tileTable)], variety, shinyTile)

					tile.y = -32
					self.tiles[y][x] = tile

					-- create a new tween to return for this tile to fall down
					tweens[tile] = {
						y = (tile.gridY - 1) * 32
					}
				end	
            end
        end
    end

    return tweens
end

function Board:render()

    for y = 1, #self.tiles do
        for x = 1, #self.tiles[1] do
            self.tiles[y][x]:render(self.x, self.y)
        end
    end
end