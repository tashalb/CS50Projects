--[[

	-- Powerup Class --

	Spawns a powerup at a random time in the game that 
	provides the player with 2 or more balls (total balls 
	is also random). Drops ball from top of screen.

]]


Powerup = Class{}


function Powerup:init(skin)

	-- size of powerup
    self.width = 16
    self.height = 16

	-- location on screen (middle for x for testing)
    self.dy = 0
	self.dx = 0

	
	self.skin = skin
	
	-- is powerup in play? starts off false
	self.inPlay = false
	
end

function Powerup:collides(target)
    -- first, check to see if the left edge of either is farther to the right
    -- than the right edge of the other

    if self.x > target.x + target.width or target.x > self.x + self.width then
        return false
    end

    -- then check to see if the bottom edge of either is higher than the top
    -- edge of the other
    if self.y > target.y + target.height or target.y > self.y + self.height then
        return false
    end 

    -- if the above aren't true, they're overlapping
    return true
end

function Powerup:reset()
	self.x = math.random(-100,100)
	self.y = 0
    self.dx = 0
    self.dy = 0
end



function Powerup:update(dt)

	if self.inPlay then
		self.y = self.y + self.dy * dt
		self.x = self.x + self.dx * dt
	end	
end


function Powerup:render()

	if self.inPlay then
		love.graphics.draw(gTextures['main'], gFrames['powerups'][self.skin],
			self.x, self.y)
	end
end
