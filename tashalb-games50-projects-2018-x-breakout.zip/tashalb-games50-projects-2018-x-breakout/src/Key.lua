--[[

	-- Key Class --

	Spawns a key at a random time in the game that 
	provides the player the ability to remove the 
	locked brick

]]


Key = Class{}


function Key:init(skin)

	-- size of key
    self.width = 16
    self.height = 16

	-- location on screen (middle for x for testing)
    self.dy = 0
	self.dx = 0

	
	self.skin = skin
	
	-- is key in play? starts off false
	self.inPlay = false
	
end

function Key:collides(target)
    -- first, check to see if the left edge of either is farther to the right
    -- than the right edge of the other

    if self.x > target.x + target.width or target.x > self.x + self.width then
        return false
    end

    -- then check to see if the bottom edge of either is higher than the top
    -- edge of the other
    if self.y > target.y + target.height or target.y > self.y + self.height then
        return false
    end 

    -- if the above aren't true, they're overlapping
    return true
end

function Key:reset()
	self.x = math.random(-100, 100)
	self.y = 0
    self.dx = 0
    self.dy = 0
end



function Key:update(dt)

	if self.inPlay then
		self.y = self.y + self.dy * dt
		self.x = self.x + self.dx * dt
	end	
end

-- render key from list of powerups

function Key:render()

	if self.inPlay then
		love.graphics.draw(gTextures['main'], gFrames['powerups'][self.skin],
			self.x, self.y)
	end
end