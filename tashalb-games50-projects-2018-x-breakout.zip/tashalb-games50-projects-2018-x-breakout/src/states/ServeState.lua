--[[
    GD50
    Breakout Remake

    -- ServeState Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    The state in which we are waiting to serve the ball; here, we are
    basically just moving the paddle left and right with the ball until we
    press Enter, though everything in the actual game now should render in
    preparation for the serve, including our current health and score, as
    well as the level we're on.
]]

ServeState = Class{__includes = BaseState}

function ServeState:enter(params)
    -- grab game state from params
    self.paddle = params.paddle
    self.bricks = params.bricks
    self.health = params.health
    self.score = params.score
    self.highScores = params.highScores
    self.level = params.level
    self.recoverPoints = params.recoverPoints
	self.paddleSize = params.paddleSize
	self.paddleColor = params.paddleColor
	self.testInPlay = params.testInPlay
	self.liveKey = params.liveKey
	self.recoverPoints = params.recoverPoints
	

    -- init new ball (random color for fun)
    self.ball = Ball()
    self.ball.skin = math.random(7)
	
	-- init 2 extra balls
	self.ball2 = Ball()
	self.ball3 = Ball()
	self.ball2.skin = math.random(7)
	self.ball3.skin = math.random(7)
	
	-- initialize powerup and pick a random one from 1 to 9
	self.powerup = Powerup()
	self.powerup.skin = math.random(9)
	
	-- initialize key
	self.key = Key()
	self.key.skin = 10
	self.isKey = params.isKey
	self.keyCollision = params.keyCollision

	

end

function ServeState:update(dt)
    -- have the ball track the player
    self.paddle:update(dt)
    self.ball.x = self.paddle.x + (self.paddle.width / 2) - 4
    self.ball.y = self.paddle.y - 8
	
	-- 2 extra balls
	self.ball2.x = self.paddle.x + (self.paddle.width / 2) - 12
    self.ball2.y = self.paddle.y - 12
	self.ball3.x = self.paddle.x + (self.paddle.width / 2) + 4
    self.ball3.y = self.paddle.y - 12
	
	-- powerup and key
	self.powerup.x = VIRTUAL_WIDTH/2 + 32
    self.powerup.y = 0
	
	self.key.x = VIRTUAL_WIDTH/2 + 32
    self.key.y = 0

    if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
        -- pass in all important state info to the PlayState
        gStateMachine:change('play', {
            paddle = self.paddle,
			paddleSize = self.paddleSize,
			paddleColor = self.paddleColor,
            bricks = self.bricks,
            health = self.health,
            score = self.score,
            highScores = self.highScores,
            ball = self.ball,
			ball2 = self.ball2,
			ball3 = self.ball3,
            level = self.level,
            recoverPoints = self.recoverPoints,
			powerup = self.powerup,
			testInPlay = self.testInPlay,
			key = self.key,
			isKey = self.isKey,
			keyCollision = self.keyCollision,
			liveKey = self.liveKey,
			recoverPoints = self.recoverPoints
			
        })
    end

    if love.keyboard.wasPressed('escape') then
        love.event.quit()
    end
end

function ServeState:render()
    self.paddle:render(self.paddleSize, self.paddleColor)
    self.ball:render()
	
    for k, brick in pairs(self.bricks) do
        brick:render()
    end

    renderScore(self.score)
    renderHealth(self.health)
	
	if self.liveKey then
		renderKey(self.keyCollision)
	elseif self.liveKey == false then
		renderKey(5)
	end	

    love.graphics.setFont(gFonts['large'])
    love.graphics.printf('Level ' .. tostring(self.level), 0, VIRTUAL_HEIGHT / 3,
        VIRTUAL_WIDTH, 'center')

    love.graphics.setFont(gFonts['medium'])
    love.graphics.printf('Press Enter to serve!', 0, VIRTUAL_HEIGHT / 2,
        VIRTUAL_WIDTH, 'center')

end