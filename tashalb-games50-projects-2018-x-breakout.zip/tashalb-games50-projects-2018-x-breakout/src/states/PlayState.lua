--[[
    GD50
    Breakout Remake

    -- PlayState Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    Represents the state of the game in which we are actively playing;
    player should control the paddle, with the ball actively bouncing between
    the bricks, walls, and the paddle. If the ball goes below the paddle, then
    the player should lose one point of health and be taken either to the Game
    Over screen if at 0 health or the Serve screen otherwise.
]]

PlayState = Class{__includes = BaseState}

--[[
    We initialize what's in our PlayState via a state table that we pass between
    states as we go from playing to serving.
]]
function PlayState:enter(params)
    self.paddle = params.paddle
	self.paddleSize = params.paddleSize
	self.paddleColor = params.paddleColor
    self.bricks = params.bricks
    self.health = params.health
    self.score = params.score
    self.highScores = params.highScores
    self.ball = params.ball
	self.ball2 = params.ball2
	self.ball3 = params.ball3
    self.level = params.level
	self.powerup = params.powerup
	self.key = params.key
	self.isKey = params.isKey
	
	self.liveKey = params.liveKey

    self.recoverPoints = params.recoverPoints

    -- give ball random starting velocity
    self.ball.dx = math.random(-200, 200)
    self.ball.dy = math.random(-60, -70)
	
	-- random velocity of powerup
	self.powerup.dy = math.random(60, 70)
	self.key.dy = math.random(60, 70)
	
	-- count for powerup spawntime, random number to compare it to. Also, collision to check if 
	-- we've already used the powerup, resetting every time we enter the playstate
	count = 0
	collision = 0
	self.keyCollision = params.keyCollision
	
	-- time passed before random ball powerup drops
	timePassed = math.random(10,12)
	
	-- when key drops, assuming the level has a key
	keyTime = math.random(15,20)
	-- distance between scores to get upgraded paddle
	scoreDistance = 0
	placeholder = 0
	
	self.testInPlay = params.testInPlay

end

function PlayState:update(dt)
    if self.paused then
        if love.keyboard.wasPressed('space') then
            self.paused = false
            gSounds['pause']:play()
        else
            return
        end
    elseif love.keyboard.wasPressed('space') then
        self.paused = true
        gSounds['pause']:play()
        return
    end

    -- update positions based on velocity
	
	self.paddle:update(dt)
	self.ball.inPlay = true
    self.ball:update(dt)
	self.powerup:update(dt)
	self.ball2:update(dt)
	self.ball3:update(dt)
	self.key:update(dt)

	
	count = count + dt

	-- increase paddle size every 200 pounts
	if self.testInPlay < 4 and scoreDistance >= 200 then
		self.testInPlay = self.testInPlay +1
		scoreDistance = 0
	end	

	
	

	-- spawn the key after x time (random) and only on some levels
	if count > keyTime and self.keyCollision == 0 and self.isKey == 1 then
		self.key.inPlay = true

	end	
	
	-- key disappears on paddle collision, and we keep the key handy until used
	if self.key:collides(self.paddle) and self.keyCollision == 0 then
		self.key.inPlay = false
		self.keyCollision = 1
		self.liveKey = true
		
	end

	
		-- spawn the powerup after x time (random)
	if count > timePassed and collision == 0 then
		self.powerup.inPlay = true

	end	
	

	-- powerup disappears when collides with paddle, and balls spawn
	if self.powerup:collides(self.paddle) and collision == 0 then
		self.powerup.inPlay = false
		collision = 1
		
		-- assign 2 extra balls a random velocity, varying the randomness

		self.ball2.dx = math.random(-200, 200)
		self.ball2.dy = math.random(-60, -70)
		self.ball3.dx = math.random(-201, 199)
		self.ball3.dy = math.random(-61, -71)
		
		-- set to in play to start the update on them
		self.ball2.inPlay = true
		self.ball3.inPlay = true
		
		
	end	

    if self.ball:collides(self.paddle) then
	
        -- raise ball above paddle in case it goes below it, then reverse dy
        self.ball.y = self.paddle.y - 8
        self.ball.dy = -self.ball.dy

        --
        -- tweak angle of bounce based on where it hits the paddle
        --

        -- if we hit the paddle on its left side while moving left...
        if self.ball.x < self.paddle.x + (self.paddle.width / 2) and self.paddle.dx < 0 then
            self.ball.dx = -50 + -(8 * (self.paddle.x + self.paddle.width / 2 - self.ball.x))
        
        -- else if we hit the paddle on its right side while moving right...
        elseif self.ball.x > self.paddle.x + (self.paddle.width / 2) and self.paddle.dx > 0 then
            self.ball.dx = 50 + (8 * math.abs(self.paddle.x + self.paddle.width / 2 - self.ball.x))
        end

        gSounds['paddle-hit']:play()
    end

    if self.ball2:collides(self.paddle) then
	
        -- raise ball above paddle in case it goes below it, then reverse dy
        self.ball2.y = self.paddle.y - 8
        self.ball2.dy = -self.ball2.dy

        --
        -- tweak angle of bounce based on where it hits the paddle
        --

        -- if we hit the paddle on its left side while moving left...
        if self.ball2.x < self.paddle.x + (self.paddle.width / 2) and self.paddle.dx < 0 then
            self.ball2.dx = -50 + -(8 * (self.paddle.x + self.paddle.width / 2 - self.ball2.x))
        
        -- else if we hit the paddle on its right side while moving right...
        elseif self.ball2.x > self.paddle.x + (self.paddle.width / 2) and self.paddle.dx > 0 then
            self.ball2.dx = 50 + (8 * math.abs(self.paddle.x + self.paddle.width / 2 - self.ball2.x))
        end

        gSounds['paddle-hit']:play()
    end
	
	if self.ball3:collides(self.paddle) then
	
        -- raise ball above paddle in case it goes below it, then reverse dy
        self.ball3.y = self.paddle.y - 8
        self.ball3.dy = -self.ball3.dy

        --
        -- tweak angle of bounce based on where it hits the paddle
        --

        -- if we hit the paddle on its left side while moving left...
        if self.ball3.x < self.paddle.x + (self.paddle.width / 2) and self.paddle.dx < 0 then
            self.ball3.dx = -50 + -(8 * (self.paddle.x + self.paddle.width / 2 - self.ball3.x))
        
        -- else if we hit the paddle on its right side while moving right...
        elseif self.ball3.x > self.paddle.x + (self.paddle.width / 2) and self.paddle.dx > 0 then
            self.ball3.dx = 50 + (8 * math.abs(self.paddle.x + self.paddle.width / 2 - self.ball3.x))
        end

        gSounds['paddle-hit']:play()
    end

    -- detect collision across all bricks with the ball
    for k, brick in pairs(self.bricks) do

        -- only check collision if we're in play
        if brick.inPlay and self.ball:collides(brick) then

            -- add to score
            self.score = self.score + (brick.tier * 200 + brick.color * 25)
			scoreDistance = scoreDistance + (brick.tier * 200 + brick.color * 25)
            -- trigger the brick's hit function, which removes it from play
            brick:hit(self.keyCollision)
			if brick.color == 0 then
				self.liveKey = false
				self.score = self.score + 500
			end	

            -- if we have enough points, recover a point of health
            if self.score > self.recoverPoints then
                -- can't go above 3 health
                self.health = math.min(3, self.health + 1)

                -- multiply recover points by 2
                self.recoverPoints = self.recoverPoints + math.min(100000, self.recoverPoints * 2)

                -- play recover sound effect
                gSounds['recover']:play()
            end

            -- go to our victory screen if there are no more bricks left
            if self:checkVictory() then
                gSounds['victory']:play()

                gStateMachine:change('victory', {
                    level = self.level,
                    paddle = self.paddle,
                    health = self.health,
                    score = self.score,
                    highScores = self.highScores,
                    ball = self.ball,
                    recoverPoints = self.recoverPoints,
					testInPlay = self.testInPlay,
					paddleSize = self.paddleSize,
					paddleColor = self.paddleColor						
                })
            end

            --
            -- collision code for bricks
            --
            -- we check to see if the opposite side of our velocity is outside of the brick;
            -- if it is, we trigger a collision on that side. else we're within the X + width of
            -- the brick and should check to see if the top or bottom edge is outside of the brick,
            -- colliding on the top or bottom accordingly 
            --

            -- left edge; only check if we're moving right, and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            if self.ball.x + 2 < brick.x and self.ball.dx > 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball.dx = -self.ball.dx
                self.ball.x = brick.x - 8
            
            -- right edge; only check if we're moving left, , and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            elseif self.ball.x + 6 > brick.x + brick.width and self.ball.dx < 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball.dx = -self.ball.dx
                self.ball.x = brick.x + 32
            
            -- top edge if no X collisions, always check
            elseif self.ball.y < brick.y then
                
                -- flip y velocity and reset position outside of brick
                self.ball.dy = -self.ball.dy
                self.ball.y = brick.y - 8
            
            -- bottom edge if no X collisions or top collision, last possibility
            else
                
                -- flip y velocity and reset position outside of brick
                self.ball.dy = -self.ball.dy
                self.ball.y = brick.y + 16
            end

            -- slightly scale the y velocity to speed up the game, capping at +- 150
            if math.abs(self.ball.dy) < 150 then
                self.ball.dy = self.ball.dy * 1.02
            end

            -- only allow colliding with one brick, for corners
            break
        end
    end
	
	
	    -- detect collision across all bricks with the ball
    for k, brick in pairs(self.bricks) do

        -- only check collision if we're in play
        if brick.inPlay and self.ball2:collides(brick) then

            -- add to score
            self.score = self.score + (brick.tier * 200 + brick.color * 25)
			scoreDistance = scoreDistance + (brick.tier * 200 + brick.color * 25)

            -- trigger the brick's hit function, which removes it from play
            brick:hit(self.keyCollision)
			if brick.color == 0 then
				self.liveKey = false
				self.score = self.score + 500
			end	
			
            -- if we have enough points, recover a point of health
            if self.score > self.recoverPoints then
                -- can't go above 3 health
                self.health = math.min(3, self.health + 1)

                -- multiply recover points by 2
                self.recoverPoints = self.recoverPoints + math.min(100000, self.recoverPoints * 2)

                -- play recover sound effect
                gSounds['recover']:play()
            end

            -- go to our victory screen if there are no more bricks left
            if self:checkVictory() then
                gSounds['victory']:play()

                gStateMachine:change('victory', {
                    level = self.level,
                    paddle = self.paddle,
                    health = self.health,
                    score = self.score,
                    highScores = self.highScores,
                    ball = self.ball,
                    recoverPoints = self.recoverPoints,
					testInPlay = self.testInPlay,
					paddleSize = self.paddleSize,
					paddleColor = self.paddleColor
                })
            end

            --
            -- collision code for bricks
            --
            -- we check to see if the opposite side of our velocity is outside of the brick;
            -- if it is, we trigger a collision on that side. else we're within the X + width of
            -- the brick and should check to see if the top or bottom edge is outside of the brick,
            -- colliding on the top or bottom accordingly 
            --

            -- left edge; only check if we're moving right, and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            if self.ball2.x + 2 < brick.x and self.ball2.dx > 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball2.dx = -self.ball2.dx
                self.ball2.x = brick.x - 8
            
            -- right edge; only check if we're moving left, , and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            elseif self.ball2.x + 6 > brick.x + brick.width and self.ball2.dx < 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball2.dx = -self.ball2.dx
                self.ball2.x = brick.x + 32
            
            -- top edge if no X collisions, always check
            elseif self.ball2.y < brick.y then
                
                -- flip y velocity and reset position outside of brick
                self.ball2.dy = -self.ball2.dy
                self.ball2.y = brick.y - 8
            
            -- bottom edge if no X collisions or top collision, last possibility
            else
                
                -- flip y velocity and reset position outside of brick
                self.ball2.dy = -self.ball2.dy
                self.ball2.y = brick.y + 16
            end

            -- slightly scale the y velocity to speed up the game, capping at +- 150
            if math.abs(self.ball2.dy) < 150 then
                self.ball2.dy = self.ball2.dy * 1.02
            end

            -- only allow colliding with one brick, for corners
            break
        end
    end
	
	
	    -- detect collision across all bricks with the ball
    for k, brick in pairs(self.bricks) do

        -- only check collision if we're in play
        if brick.inPlay and self.ball3:collides(brick) then

            -- add to score
            self.score = self.score + (brick.tier * 200 + brick.color * 25)
			scoreDistance = scoreDistance + (brick.tier * 200 + brick.color * 25)
			
            -- trigger the brick's hit function, which removes it from play. Send key brick info
			-- to make sure it can be removed. Also, add 500 extra points if gold
            brick:hit(self.keyCollision)
			if brick.color == 0 then
				self.score = self.score + 500
				self.liveKey = false
			end	
	
            -- if we have enough points, recover a point of health
            if self.score > self.recoverPoints then
                -- can't go above 3 health
                self.health = math.min(3, self.health + 1)

                -- multiply recover points by 2
                self.recoverPoints = self.recoverPoints + math.min(100000, self.recoverPoints * 2)

                -- play recover sound effect
                gSounds['recover']:play()
            end

            -- go to our victory screen if there are no more bricks left
            if self:checkVictory() then
                gSounds['victory']:play()

                gStateMachine:change('victory', {
                    level = self.level,
                    paddle = self.paddle,
					paddleColor = self.paddleColor,
					paddleSize = self.paddleSize,
                    health = self.health,
                    score = self.score,
                    highScores = self.highScores,
                    ball = self.ball,
                    recoverPoints = self.recoverPoints,
					testInPlay = self.testInPlay
                })
            end

            --
            -- collision code for bricks
            --
            -- we check to see if the opposite side of our velocity is outside of the brick;
            -- if it is, we trigger a collision on that side. else we're within the X + width of
            -- the brick and should check to see if the top or bottom edge is outside of the brick,
            -- colliding on the top or bottom accordingly 
            --

            -- left edge; only check if we're moving right, and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            if self.ball3.x + 2 < brick.x and self.ball3.dx > 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball3.dx = -self.ball3.dx
                self.ball3.x = brick.x - 8
            
            -- right edge; only check if we're moving left, , and offset the check by a couple of pixels
            -- so that flush corner hits register as Y flips, not X flips
            elseif self.ball3.x + 6 > brick.x + brick.width and self.ball3.dx < 0 then
                
                -- flip x velocity and reset position outside of brick
                self.ball3.dx = -self.ball3.dx
                self.ball3.x = brick.x + 32
            
            -- top edge if no X collisions, always check
            elseif self.ball3.y < brick.y then
                
                -- flip y velocity and reset position outside of brick
                self.ball3.dy = -self.ball3.dy
                self.ball3.y = brick.y - 8
            
            -- bottom edge if no X collisions or top collision, last possibility
            else
                
                -- flip y velocity and reset position outside of brick
                self.ball3.dy = -self.ball3.dy
                self.ball3.y = brick.y + 16
            end

            -- slightly scale the y velocity to speed up the game, capping at +- 150
            if math.abs(self.ball3.dy) < 150 then
                self.ball3.dy = self.ball3.dy * 1.02
            end

            -- only allow colliding with one brick, for corners
            break
        end
    end

    -- if ball goes below bounds, revert to serve state and decrease health
	
	if self.ball.y >= VIRTUAL_HEIGHT and collision == 0 then
		self.health = self.health - 1
        gSounds['hurt']:play()
		
		if self.paddleSize > 1 then
			self.paddleSize = self.paddleSize - 1
			self.testInPlay = self.testInPlay - 1
		end	


		Paddle:render(self.paddleSize, self.paddleColor)
        if self.health == 0 then
            gStateMachine:change('game-over', {
                score = self.score,
                highScores = self.highScores
            })
        else
            gStateMachine:change('serve', {
                paddle = self.paddle,
				paddleSize = self.paddleSize,
				paddleColor = self.paddleColor,
                bricks = self.bricks,
                health = self.health,
                score = self.score,
                highScores = self.highScores,
                level = self.level,
                recoverPoints = self.recoverPoints,
				testInPlay = self.testInPlay,
				isKey = self.isKey,
				keyCollision = self.keyCollision,
				liveKey = self.liveKey
            })
        end
	
    elseif self.ball.y >= VIRTUAL_HEIGHT and self.ball2.y >= VIRTUAL_HEIGHT and self.ball3.y >= VIRTUAL_HEIGHT then
        self.health = self.health - 1
        gSounds['hurt']:play()
		
		self.paddleSize = self.paddleSize - 1
		Paddle:render(self.paddleSize, self.paddleColor)
		self.testInPlay = self.testInPlay - 1

        if self.health == 0 then
            gStateMachine:change('game-over', {
                score = self.score,
                highScores = self.highScores
            })
        else
            gStateMachine:change('serve', {
                paddle = self.paddle,
				paddleSize = self.paddleSize,
				paddleColor = self.paddleColor,
                bricks = self.bricks,
                health = self.health,
                score = self.score,
                highScores = self.highScores,
                level = self.level,
                recoverPoints = self.recoverPoints,
				testInPlay = self.testInPlay,
				isKey = self.isKey,
				keyCollision = self.keyCollision,
				liveKey = self.liveKey
            })
        end
    end

	

    -- for rendering particle systems
    for k, brick in pairs(self.bricks) do
        brick:update(dt)
    end

    if love.keyboard.wasPressed('escape') then
        love.event.quit()
    end
end

function PlayState:render()
    
	
	-- render bricks
    for k, brick in pairs(self.bricks) do
        brick:render()
    end

    -- render all particle systems
    for k, brick in pairs(self.bricks) do
        brick:renderParticles()
    end
	
	-- different paddle sizes to render
	if self.testInPlay == 1 then
		self.paddleSize = 1
		self.paddle:render(self.paddleSize, self.paddleColor)
	end
	
	if self.testInPlay == 3 then
		self.paddleSize = 3
		self.paddle:render(self.paddleSize, self.paddleColor)
	end
	
	if self.testInPlay == 2 then 	
		self.paddleSize = 2
		self.paddle:render(self.paddleSize, self.paddleColor)
	end
	
	if self.testInPlay == 4 then
		self.paddleSize = 4
		self.paddle:render(self.paddleSize, self.paddleColor)
	end
	
	
    self.ball:render()
	self.ball2:render()
	self.ball3:render()
	self.powerup:render()
	self.key:render()


    renderScore(self.score)
    renderHealth(self.health)
	
	if self.liveKey then
		renderKey(self.keyCollision)
	elseif self.liveKey == false then
		renderKey(5)
	end	

    -- pause text, if paused
    if self.paused then
        love.graphics.setFont(gFonts['large'])
        love.graphics.printf("PAUSED", 0, VIRTUAL_HEIGHT / 2 - 16, VIRTUAL_WIDTH, 'center')
    end
end


function PlayState:checkVictory()
    for k, brick in pairs(self.bricks) do
        if brick.inPlay then
            return false
        end 
    end

    return true
end