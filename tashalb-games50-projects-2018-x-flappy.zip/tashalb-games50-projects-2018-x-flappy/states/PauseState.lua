--[[

  When pressing the "tab" key, the game will stop in the middle of play
]]


PauseState = Class{__includes = BaseState}

local PAUSE_BUTTON = love.graphics.newImage('pause.png')

function PauseState:init()
    self.timer = 0
    self.enterParams = {}
end


function PauseState:enter(params)
	-- used to pass variables between play and pause states
	self.score = params.score
	self.bird = params.bird
	self.timer = params.timer
	self.pipePairs = params.pipePairs
	sounds['music']:pause()
	sounds['pause']:play()
	scrolling = false
end	


function PauseState:update(dt)

	 self.timer = self.timer + dt

	-- once in this state, can press 'p' again to unpause
	if love.keyboard.wasPressed('p') then
		gStateMachine:change('play', {score=self.score, bird = self.bird, timer = self.timer, pipePairs = self.pipePairs})
    end
	
end


function PauseState:render()
    
	-- displays pause menu
	love.graphics.setFont(flappyFont)
    love.graphics.draw(PAUSE_BUTTON, VIRTUAL_WIDTH/2-70, VIRTUAL_HEIGHT/2-60)
	--love.graphics.print(self.timer .. tostring(self.score), 8, 38)
end